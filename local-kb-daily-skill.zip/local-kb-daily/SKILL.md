

# kb-daily — 用户私有 MCP（每日页面部署）

通过用户的私有 MCP 服务器 `https://mcp.189166.xyz/mcp`（serverInfo: `kb-daily-deploy`）
在用户自己的服务器上发布/管理每日页面。公网地址：`https://kb.189166.xyz/daily/`。

## 调用方式

用随附的脚本（它处理 MCP initialize/session/握手，token 从文件读取）：

```bash
~/workspace/custom-skills/local-kb-daily/bin/kb-daily-call <tool> '<json-args>'
```

认证：Bearer token 存在 `~/.kb-daily-token`（600 权限，用户 2026-10-11 亲手贴出要求接入）。
可用环境变量覆盖：`KB_DAILY_TOKEN_FILE`、`KB_DAILY_MCP_URL`。
**token 绝不在对话、报告、日志或记忆里复述；只通过该文件传递。**

## 工具（2026-10-11 实测 7 个，全部端到端验证过）

| tool | 用途 | 参数 |
|---|---|---|
| `list_pages` | 列出已发布日期目录与资源统计 | 无 |
| `deploy_html` | 上传某天页面 HTML → `/daily/<date>/index.html` | `date`: YYYY-MM-DD；`html`: 完整 HTML（≤2MB） |
| `deploy_asset` | 上传静态资源（封面/题目配图） | `kind`: covers\|qimg；`filename` 如 2026-10-11.png；`content_base64`（≤2MB） |
| `deploy_index` | 重新生成归档首页 `/daily/index.html`（3 秒跳转最新一期） | 无 |
| `delete_page` | 删除某天页面目录（不动 assets） | `date` |
| `verify_page` | 校验部署：本机+公网 HTTP 状态、OG 标签、封面图 | `date` |
| `share_link` | 返回该天的微信推送链接（带缓存绕过参数） | `date` |

示例：

```bash
~/workspace/custom-skills/local-kb-daily/bin/kb-daily-call deploy_html \
  '{"date":"2026-10-11","html":"<!doctype html>..."}'
~/workspace/custom-skills/local-kb-daily/bin/kb-daily-call verify_page '{"date":"2026-10-11"}'
```

返回是 MCP JSON-RPC 信封；`result.structuredContent.result` 是业务 JSON 字符串，
`result.content[0].text` 是同内容的文本版。

## 微信预览图（封面）

每次部署必须带微信预览图（用户 2026-10-11 立的规矩：以后必须有微信预览图）。

- 规格：**1200×600 PNG、无文字**（标题走 `og:title`，不要画进图里）。
- 生成：用 cairosvg 把 SVG 转 PNG；成品放 `~/workspace/kb-covers/<日期>.png`，
  aliyun 路径 `/daily/assets/covers/<日期>.png`。
- 上传：`deploy_asset`，`kind` 为 `covers`，`filename` 如 `2026-10-11.png`（≤2MB）。
- 页面 OG：`og:title` / `og:image`（指向封面 URL）/ `og:url` 必须齐全；
  `verify_page` 会校验 OG 标签与封面图 HTTP 200。

## 约束

- 部署前必须得到用户明确指令（发布/更新哪天的页面、用什么内容）。
- `delete_page` 是破坏性操作：只在用户明确要求删除某天页面时调用，执行前先
  `list_pages` 确认日期无误。
- 每次 `deploy_html` 成功后都跑一次 `verify_page` 确认公网 200，再给用户链接。
- token 泄露或用户要求时：提醒用户在其服务器侧轮换 token，然后更新
  `~/.kb-daily-token`（保持 600）。
- 若服务器返回 401：token 可能已轮换，先告诉用户，不要反复重试。
## Available connectors

Use `muse.connector_search` to find the current connector docs before following
recovered instructions.
